import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;



public class FindDiameter {
	
	// function to build the a graph from the two CSV files
	private static Graph buildGraphFromData(File stopPath, File edgePath) throws IOException {
		
				
		List<String> stops = FileUtils.readLines(stopPath, StandardCharsets.UTF_8);
		
		// Creation of the nodes from the names gives in the file and put all the nodes in a List nodeList
		List<Node> nodeList = new ArrayList<Node>();
		for (int i = 1; i < stops.size(); i++) {
			String[] stopInfos = stops.get(i).split(",");
			Node n = new Node(stopInfos[1]);
			nodeList.add(Integer.parseInt(stopInfos[0]), n);
		}
		
		
		List<String> edges = FileUtils.readLines(edgePath, StandardCharsets.UTF_8);
		
		// adding all the edges by setting the "adjacentNodes" list of each nodes in the List nodeList
		for (int i = 1; i < edges.size(); i++) {
			String[] edgeInfos = edges.get(i).split(",");
			
			Double dist = Double.parseDouble(edgeInfos[2]);
			int distance = (int) Math.round(dist);
			
			// its an undirected graph so we put a link from A to B and from B to A
			nodeList.get(Integer.parseInt(edgeInfos[0])).addDestination(nodeList.get(Integer.parseInt(edgeInfos[1])), distance);
			nodeList.get(Integer.parseInt(edgeInfos[1])).addDestination(nodeList.get(Integer.parseInt(edgeInfos[0])), distance);
		}
		
		// creating the graph		
		Graph graph = new Graph();
		
		// adding all the nodes to the graph
		for (int i = 1; i < nodeList.size(); i++) {
			graph.addNode(nodeList.get(i));
		}
		
		
		return graph;
		
	}
	
	// function to find the diameter of a graph
	private static void diameter(Graph g) {
		
		// extract all the nodes of the graph in a List nodeList
		Iterator<Node> it = g.getNodes().iterator();
		List<Node> nodeList = new ArrayList<Node>();
		while(it.hasNext()) {
			Node d = it.next();
			nodeList.add(d);
		}
		
		// doing the dijkstra algorithme starting from every possible node
		List<Node> diametersSelected = new ArrayList<Node>();
		for(int i = 0; i < nodeList.size(); i++) {
			g = Dijkstra.calculateShortestPathFromSource(g, nodeList.get(i));
			
			// extract the node with the best excentricity from the current source 
			Node n1 = inspector(g);
						
			Node n = new Node("NULL");
			n.setName(n1.getName());
			n.setDistance(n1.getDistance());
			n.setAdjacentNodes(n1.getAdjacentNodes());
			n.setShortestPath((LinkedList<Node>) n1.getShortestPath());
			
			//put this node with the current configuration in a list of best excentricity node from a certain source
			diametersSelected.add(n);
			
			// put the default configuration for all nodes, so infinite diameter and empty shortpath
			LinkedList<Node> shortestPath = new LinkedList<>();
			for(int j = 0; j < nodeList.size(); j++) {
				nodeList.get(j).setDistance(Integer.MAX_VALUE);
				nodeList.get(j).setShortestPath(shortestPath);
			}
		}
		
		// finding the best excentricity of all the nodes selected 
		int dMax = 0;
		Node finalDiameter = new Node("NULL");
		for(int i = 0; i < diametersSelected.size(); i++) {
			if(diametersSelected.get(i).getDistance() > dMax) {
				finalDiameter = diametersSelected.get(i);
			}
		}
		
		
		
		printDiameter(finalDiameter);
		
	}
	
	// function to find the node with the best excentricity from a graph which has been in the diskjtra algorithm from a source
	private static Node inspector(Graph g) {
		
		Iterator<Node> it = g.getNodes().iterator();
		int dMax = 0;
		Node n = new Node("NULL");
		while(it.hasNext()) {
			Node d = it.next();
			
			if(d.getDistance() > dMax) {
				dMax = d.getDistance();
				n = d;
			}
		}
		
		return n;
	}
	
	// print solution
	private static void printDiameter(Node n) {
		
		System.out.println("");
		System.out.println("");
		System.out.println("");
		System.out.println("Longest Path : ");
		System.out.println("");
		for(int i = 0; i < n.getShortestPath().size(); i++) {
			System.out.print(n.getShortestPath().get(i).getName() + " => ");
		}
		System.out.println(n.getName());
		
		
		System.out.println(" ");
		System.out.println("");
		System.out.println("Lengths of sub-paths :");
		System.out.println("");
		for(int i = 0; i < n.getShortestPath().size(); i++) {
			 
			for(java.util.Map.Entry<Node, Integer> entry : n.getShortestPath().get(i).getAdjacentNodes().entrySet()) {
				Node cle = entry.getKey();
				Integer valeur = entry.getValue();
				
				if(i != n.getShortestPath().size() - 1 ) {
					if(cle == n.getShortestPath().get(i+1)) {
						System.out.println(n.getShortestPath().get(i).getName()+" => "+cle.getName()+" : "+ valeur);
					}
				} else { 
					if (cle.getName().equals(n.getName())) {
						System.out.println(n.getShortestPath().get(i).getName()+" => "+n.getName()+" : "+ valeur);
					}
				}
			}
		}
		
		System.out.println(" ");
		System.out.println("Total length of the path : " + n.getDistance() + " meters.");
	}

	public static void main(String[] args) throws IOException {
		
		DataExtractor.extractData();
		File stopPath = new File("data-output/stop-rel.csv");
		File edgePath = new File("data-output/edge.csv");
		Graph graph = buildGraphFromData(stopPath,edgePath);
		diameter(graph);

	}
}
